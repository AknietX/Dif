<script setup>
import axios from 'axios';

import { ref, inject } from 'vue';
import { extractIdentifiers } from 'vue/compiler-sfc';
const imageUrl = ref(null)
const fileInput = ref(null);
const selectedFile = ref(null);
const name = ref()

const { today } = inject('cart')

const handleFileChange = (event) => {
  const file = event.target.files[0];
  if (file) {
    selectedFile.value = file;
    imageUrl.value = URL.createObjectURL(file); // Превью фото
  }
};

const openFilePicker = () => {
  fileInput.value.click(); // Симуляция клика по скрытому input
};
const provereno = ref()
const Proverka = (event)=>{
  provereno.value = event.target.value
}

const uploadPhoto = async () => {
  try {
    const response = await axios.post(`https://9e40d05721309bab.mokky.dev/${provereno.value}`, {
      imgScreen: imageUrl.value,
      Title:name.value,
      time: today.value
    });
    console.log('Фото загружено:', response.data);
  } catch (error) {
    console.error('Ошибка загрузки:', error);
  }
};
</script>


<template>
  <div class="absolute mt-0 ml-0 z-10 w-screen h-full bg-white flex items-center justify-center">
    <div>
      <div class="flex-col mb-4"  >
        <label for="name" class="block mb-1">Введите имя:</label>
        <input v-model="name" id="name" class="block border w-40 px-1 py-1" type="text" placeholder="текст...">

        <label for="city block">Выберите дело</label>
        <select v-on:change="Proverka" id="city" class="block border w-40 px-2 py-1">
        <option value="house">Весь дом</option>
        <option value="prih">Прихожка</option>
        <option value="posud">Посуда</option>
        </select>
      </div>
      <div class="mt-4 bg-black w-40 h-40">
         <img v-if="imageUrl" :src="imageUrl" alt="Превью" class="w-40 h-40 object-cover rounded shadow">
      </div>


    <input type="file" ref="fileInput" @change="handleFileChange" accept="image/*" class="hidden">
    <button @click="openFilePicker" class="bg-blue-500 text-white px-4 py-2 rounded">Выбрать фото</button>
      <div>

      </div>
      <button @click="uploadPhoto" class="mt-4 bg-green-500 text-white px-4 py-2 rounded">Готово</button>
    </div>



  </div>
</template>
